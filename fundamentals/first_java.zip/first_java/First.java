public class First {
    public static void main(String[] args) {
        System.out.println("My name is Hadhri Rihem");
        System.out.println("I am 20 years old");
        System.out.println("My home town is in Tunis");
    }
}
